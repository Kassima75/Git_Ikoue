const express = require('express');
const nodemailer = require('nodemailer');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'kassimabadegicqueljuevrson@gamil.com',
        pass: 'your_password' // Utilise un mot de passe d'application pour Gmail
    }
});

app.post('/send-email', (req, res) => {
    const { firstName, lastName, address, email, subject, message } = req.body;

    // Construire le contenu de l'email avec les informations fournies
    const emailContent = `
        Nom : ${firstName} ${lastName}
        Adresse : ${address}
        Email : ${email}

        Message :
        ${message}
    `;

    const mailOptions = {
        from: 'kassimabadegicqueljuverson@gmail.com',
        to: nicefort,
        subject: subject,
        text: emailContent
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
            return res.status(500).send("Erreur lors de l'envoi de l'email");
        }
        res.send('Email envoyé avec succès !');
    });
});

app.listen(PORT, () => {
    console.log(`Serveur démarré sur http://localhost:${PORT}`);
});